import {Component, OnInit} from '@angular/core';

/**
 * @title Radios with ngModel
 */

class plant {
  public name: string;
  public imgUrl: string;
  public quiz: string[];
}


@Component({
  selector: 'radio-ng-model-example',
  templateUrl: 'radio-ng-model-example.html',
  styleUrls: ['radio-ng-model-example.css'],
})
export class RadioNgModelExample implements OnInit {
  plants: plant[];

  public selectedPlant: plant;

  possibilities: string[] = [
      "Green Ash",
      "Basswood",
      "Bald Cypress",
      "American Beech",
      "River Birch",
      "Eastern Cottonwood",
      "Cigar Tree",
      "Purple Cone Flower"
  ];

  ready: boolean = false;

  public correct: boolean = false;
  public guessed: boolean = false;
  constructor(){
  }

  ngOnInit(){
   this.setQuestion();
  }

  setQuestion(){
 this.plants = [];
    let plant1: plant = new plant();
    plant1.name = "Purple Coneflower";
    plant1.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/purple-coneflower.jpg";
    plant1.quiz = this.getPossibilities(plant1.name);
    plant1.quiz.push(plant1.name);
    plant1.quiz = this.shuffle(plant1.quiz);
    this.possibilities.push(plant1.name);
    this.plants.push(plant1);
     
    plant1.quiz = this.shuffle(plant1.quiz);

    let plant2: plant = new plant();
    plant2.name = "Butterfly Milkweed";
    plant2.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2015/07/butterfly-milkweed.jpg";
    plant2.quiz = this.getPossibilities(plant2.name);
    plant2.quiz.push(plant2.name);
    this.possibilities.push(plant2.name);
    plant2.quiz = this.shuffle(plant2.quiz);
    this.plants.push(plant2);


        let plant3: plant = new plant();
    plant3.name = "Royal Catchfly";
    plant3.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/royal-catchfly.jpg";
    plant3.quiz = this.getPossibilities(plant3.name);
    plant3.quiz.push(plant3.name);
    this.possibilities.push(plant3.name);
        plant3.quiz = this.shuffle(plant3.quiz);
    this.plants.push(plant3);


        let plant4: plant = new plant();
    plant4.name = "Winterberry";
    plant4.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/winterberry.jpg";
    plant4.quiz = this.getPossibilities(plant4.name);
    plant4.quiz.push(plant4.name);
    this.possibilities.push(plant4.name);
    plant4.quiz = this.shuffle(plant4.quiz);
    this.plants.push(plant4);


    let plant5: plant = new plant();
    plant5.name = "Spicebush";
    plant5.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/spicebush.jpg";
    plant5.quiz = this.getPossibilities(plant4.name);
    plant5.quiz.push(plant5.name);
    plant5.quiz = this.shuffle(plant5.quiz);
    this.plants.push(plant5);


    let plant6: plant = new plant();
    plant6.name = "Redbud";
    plant6.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/redbud-in-bloom.jpg";
    plant6.quiz = this.getPossibilities(plant4.name);
    plant6.quiz.push(plant6.name);
    plant6.quiz = this.shuffle(plant6.quiz);
    this.plants.push(plant6);


    let plant7: plant = new plant();
    plant7.name = "Wild Columbine";
    plant7.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/wild-columbine.jpg";
    plant7.quiz = this.getPossibilities(plant7.name);
    plant7.quiz.push(plant7.name);
    plant7.quiz = this.shuffle(plant7.quiz);
    this.plants.push(plant7);

let plant8: plant = new plant();
    plant8.name = "Blueberries";
    plant8.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/blueberry-blossoms1.jpg";
    plant8.quiz = this.getPossibilities(plant8.name);
    plant8.quiz.push(plant8.name);
    plant8.quiz = this.shuffle(plant8.quiz);
    this.plants.push(plant8);

let plant9: plant = new plant();
    plant9.name = "Trumpet Honeysuckle";
    plant9.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/trumpet-honeysuckle.jpg";
    plant9.quiz = this.getPossibilities(plant9.name);
    plant9.quiz.push(plant9.name);
    plant9.quiz = this.shuffle(plant9.quiz);
    this.plants.push(plant9);

let plant10: plant = new plant();
    plant10.name = "Arrow-wood Viburnum";
    plant10.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/arrow-wood-virbunum.jpg";
    plant10.quiz = this.getPossibilities(plant10.name);
    plant10.quiz.push(plant10.name);
    plant10.quiz = this.shuffle(plant10.quiz);
    this.plants.push(plant10);

let plant11: plant = new plant();
    plant11.name = "Dutchman’s Pipevine";
    plant11.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/dutchmans-pipevine.jpg";
    plant11.quiz = this.getPossibilities(plant11.name);
    plant11.quiz.push(plant11.name);
    plant11.quiz = this.shuffle(plant11.quiz);
    this.plants.push(plant11);

let plant12: plant = new plant();
    plant12.name = "False Blue Indigo";
    plant12.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/false-blue-indigo.jpg";
    plant12.quiz = this.getPossibilities(plant12.name);
    plant12.quiz.push(plant12.name);
    plant12.quiz = this.shuffle(plant12.quiz);
    this.plants.push(plant12);

let plant13: plant = new plant();
    plant13.name = "Virginia Sweetspire";
    plant13.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/virginia-sweetspire.jpg";
    plant13.quiz = this.getPossibilities(plant13.name);
    plant13.quiz.push(plant13.name);
    plant13.quiz = this.shuffle(plant13.quiz);
    this.plants.push(plant13);

let plant14: plant = new plant();
    plant14.name = "Golden Alexander";
    plant14.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/pot-of-parsley.jpg";
    plant14.quiz = this.getPossibilities(plant14.name);
    plant14.quiz.push(plant14.name);
    plant14.quiz = this.shuffle(plant14.quiz);
    this.plants.push(plant14);

let plant15: plant = new plant();
    plant15.name = "Button Bush";
    plant15.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/button-bush.jpg";
    plant15.quiz = this.getPossibilities(plant15.name);
    plant15.quiz.push(plant15.name);
    plant15.quiz = this.shuffle(plant15.quiz);
    this.plants.push(plant15);

let plant16: plant = new plant();
    plant16.name = "Scarlet Bee Balm";
    plant16.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2011/06/black-swallowtail-on-bee-balm-blog.jpg";
    plant16.quiz = this.getPossibilities(plant16.name);
    plant16.quiz.push(plant16.name);
    plant16.quiz = this.shuffle(plant16.quiz);
    this.plants.push(plant16);

let plant17: plant = new plant();
    plant17.name = "Common Milkweed";
    plant17.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/common-milkweed.jpg";
    plant17.quiz = this.getPossibilities(plant17.name);
    plant17.quiz.push(plant17.name);
    plant17.quiz = this.shuffle(plant17.quiz);
    this.plants.push(plant17);

let plant18: plant = new plant();
    plant18.name = "Purple Milkweed";
    plant18.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/purple-milkweed-and-monarch.jpg";
    plant18.quiz = this.getPossibilities(plant18.name);
    plant18.quiz.push(plant18.name);
    plant18.quiz = this.shuffle(plant18.quiz);
    this.plants.push(plant18);

let plant19: plant = new plant();
    plant19.name = "Swamp Milkweed";
    plant19.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/swamp-milkweed.jpg";
    plant19.quiz = this.getPossibilities(plant19.name);
    plant19.quiz.push(plant19.name);
    plant19.quiz = this.shuffle(plant19.quiz);
    this.plants.push(plant19);

let plant20: plant = new plant();
    plant20.name = "Tropical Milkweed";
    plant20.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/monarch-on-tropical-milkweed.jpg";
    plant20.quiz = this.getPossibilities(plant20.name);
    plant20.quiz.push(plant20.name);
    plant20.quiz = this.shuffle(plant20.quiz);
    this.plants.push(plant20);

let plant21: plant = new plant();
    plant21.name = "Sweet Coneflower";
    plant21.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/sweet-coneflower.jpg";
    plant21.quiz = this.getPossibilities(plant21.name);
    plant21.quiz.push(plant21.name);
    plant21.quiz = this.shuffle(plant21.quiz);
    this.plants.push(plant21);

let plant22: plant = new plant();
    plant22.name = "Blazing Stars";
    plant22.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/blazing-star.jpg";
    plant22.quiz = this.getPossibilities(plant22.name);
    plant22.quiz.push(plant22.name);
    plant22.quiz = this.shuffle(plant22.quiz);
    this.plants.push(plant22);

let plant23: plant = new plant();
    plant23.name = "Mist Flower";
    plant23.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/mist-flower.jpg";
    plant23.quiz = this.getPossibilities(plant23.name);
    plant23.quiz.push(plant23.name);
    plant23.quiz = this.shuffle(plant23.quiz);
    this.plants.push(plant23);

let plant24: plant = new plant();
    plant24.name = "Hearts-a-Burstin’";
    plant24.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2011/10/hearts-a-burstin.jpg";
    plant24.quiz = this.getPossibilities(plant24.name);
    plant24.quiz.push(plant24.name);
    plant24.quiz = this.shuffle(plant24.quiz);
    this.plants.push(plant24);

let plant25: plant = new plant();
    plant25.name = "New England Aster";
    plant25.imgUrl = "https://www.bettyhallphotography.com/wp-content/uploads/2012/02/new-england-aster.jpg";
    plant25.quiz = this.getPossibilities(plant25.name);
    plant25.quiz.push(plant25.name);
    plant25.quiz = this.shuffle(plant25.quiz);
    this.plants.push(plant25);

    this.selectedPlant = this.plants[this.random(this.plants.length - 1)];
    console.log("selected plant: ", this.selectedPlant);
    this.ready = true;
  }

  public random(num: number){
    return Math.floor(Math.random() * num);
  }

  getPossibilities(avoid: string): string[] {
    let poss: any = {};
    while(Object.keys(poss).length < 4){
      let p: string = this.possibilities[this.random(this.possibilities.length - 1)];
      console.log(p);
      if(p != avoid){
          poss[p] = true;
      }
    }

    console.log("poss: ", poss);

    return Object.keys(poss);
  }

  favoriteSeason: string;
  seasons: string[] = ['Winter', 'Spring', 'Summer', 'Autumn'];


public checkAnswer(answer: string){
  this.guessed = true;
  this.correct = this.selectedPlant.name == answer;

}

public next(){
  this.guessed = false;
  this.correct = false;
  this.setQuestion();
}

public shuffle(array: string[]) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}


}


/**  Copyright 2019 Google Inc. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */


/**  Copyright 2019 Google Inc. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */